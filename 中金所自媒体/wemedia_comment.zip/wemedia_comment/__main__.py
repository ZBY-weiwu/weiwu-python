# -*- coding:utf-8 -*-
# author: golaxy
# email: by951118@163.com
# date: 2021/10/13


# from task_scheduling import WemediaCommentTaskScheduling
#
# if __name__ == '__main__':
#     TaskScheduling = WemediaCommentTaskScheduling()
#     TaskScheduling.download_main(