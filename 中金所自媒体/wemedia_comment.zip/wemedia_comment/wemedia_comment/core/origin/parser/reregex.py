# -*- coding:utf-8 -*-
# author: origin
# email: 1194542196@qq.com
# date: 2021/7/16


class ReverseRegexParser(object):
    @classmethod
    def parse(cls, *args, **kwargs):
        pass
