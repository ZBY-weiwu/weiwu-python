# -*- coding:utf-8 -*-
# author: zby
# email: by951118@163.com
# date: 2021/7/28

import re
import random
import time
import requests
import json
from lxml import etree
from requests_html import HTMLSession
from urllib.parse import urljoin
import asyncio


from scrapy.cmdline import execute
from Schedulingredis import SchedulingRedis

def scrapy_main():
    while True:
        # SchedulingRedis().dispatch_spider()
        # time.sleep(3)
        execute(["scrapy", "crawl", "wemedia_comment"])

if __name__ == '__main__':
    scrapy_main()
    # execute(["scrapy", "crawl", "wemedia_comment"])




