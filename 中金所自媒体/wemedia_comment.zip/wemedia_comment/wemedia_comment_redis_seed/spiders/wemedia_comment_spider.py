import scrapy
import os
import json
import time
from wemedia_comment.spiders.choice_spider import abstractFactory
from wemedia_comment.core.golaxy.common.utils import db
import configparser
import sys

parent_dir = os.path.dirname(os.path.abspath(__file__))
conf = configparser.ConfigParser()

conf.read( "./config/config.ini", encoding="utf-8")
logger_path = conf.get("LoggerPath", "task_seed_logger_path")
es_hosts = conf.get("Es", "es_hosts")
index_name = conf.get("Es", "index_name")
es_user = conf.get("Es", "es_user")
es_password = conf.get("Es", "es_password")
seed_generation_number = int(conf.get("TaskSchedul", "seed_generation_number"))
task_files_count = int(conf.get("TaskSchedul", "task_files_count"))


# redis_config
redis_hosts = conf.get("Redis", "hosts")
redis_port = conf.get("Redis", "port")
redis_db = conf.get("Redis", "db")
redis_table = conf.get("Redis", "redis_table")

class media_commentSpider(scrapy.Spider):

    name = "wemedia_comment"
    board_sc = db.RedisQueueScheduler(redis_kwargs={
        'host': redis_hosts,
        "port": redis_port,
        "db": redis_db
    })
    def __init__(self):
        print ("wemedia_comment")
        self.seed_item_list = []
        self.raedRedis()

        print("board_sc:",self.board_sc)
    def raedRedis(self):
        #trim = True 的时候 是去一次 删一次
        seedcontent = self.board_sc.get(redis_table, trim=False)
        if len(seedcontent)==0:
            time.sleep(30)
            return
        # seedcontent =['{"site_name": "东方财富APP", "site_id": 91, "board_name": "东方财富APP-评论", "board_id": -1, "url": "http://mguba.eastmoney.com/mguba/article/0/1093595424", "detail_id": "1093595424", "detail_url": "http://guba.eastmoney.com/interface/GetData.aspx", "insert_time": 1634288819}', '{"site_name": "东方财富APP", "site_id": 91, "board_name": "东方财富APP-评论", "board_id": -1, "url": "http://mguba.eastmoney.com/mguba/article/0/1093595431", "detail_id": "1093595431", "detail_url": "http://guba.eastmoney.com/interface/GetData.aspx", "insert_time": 1634288819}']

        for sub in seedcontent:
            sub = json.loads(sub)
            seed_item={}
            seed_item["detail_id"] = sub['detail_id']
            seed_item["detail_url"] = sub['detail_url']
            seed_item["site_id"] = sub['site_id']
            seed_item["site_name"] = sub["site_name"]
            seed_item["board_name"] = sub["board_name"]
            seed_item["board_id"] = sub["board_id"]
            seed_item["url"] = sub.get("url","")
            seed_item["total_page"] = 0
            self.seed_item_list.append(seed_item)

    def start_requests(self):
        # print(self.seed_item_list)
        for cfg in self.seed_item_list:
            spider = abstractFactory().getFactory(cfg["site_id"]).formatEntryUrl(cfg)
            if not spider:
                continue
            yield spider
