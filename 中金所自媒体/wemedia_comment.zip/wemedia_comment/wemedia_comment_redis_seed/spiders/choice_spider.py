# -*- coding:utf-8 -*-
# author: zby
# email: by951118@163.com
# date: 2021/8/4

import re
import random
import time
import requests
import json
from lxml import etree
from requests_html import HTMLSession
from urllib.parse import urljoin


class abstractFactory(object):
    def __init__(self):
        pass

    def getFactory(self, comment_id):

        if comment_id == 91:
            from .guba_comment_spider import DongfangcaifugubaCommentSpider
            return DongfangcaifugubaCommentSpider()
        if comment_id == 8:
            from .toutiao_comment_spider import JinritoutiaoCommentSpider
            return JinritoutiaoCommentSpider()
        if comment_id == 77:
            from .xueqiu_comment_spider import XueqiuCommentSpider
            return XueqiuCommentSpider()


