import scrapy
import os
import json
import copy
import re
import time
import urllib.parse
from urllib.parse import urljoin
import configparser
from fake_useragent import UserAgent
from wemedia_comment.items import WemediaCommentItem,ChildCommentItem
from scrapy.utils.project import get_project_settings
from lxml import etree

from wemedia_comment.Tools.wenda_package import get_logger,Get_md5,str_to_timestamp,timeStamp_data
from wemedia_comment.Tools.dupClient import DUPClient
from wemedia_comment.Tools.golaxy_request import Downloader_HTML as golaxy_Downloader

dupClient = DUPClient()


parent_dir = os.path.dirname(os.path.abspath(__file__))
conf = configparser.ConfigParser()
conf.read(parent_dir + "/../../config/config.ini", encoding="utf-8")
logger_path = conf.get("LoggerPath", "logger_path")

os_path = os.getcwd()
ua = UserAgent(path=r".\wemedia_comment\Tools\useragent.json")


class XueqiuCommentSpider():
    def __init__(self):
        print("XueqiuCommentSpider")

        settings = get_project_settings()
        self.DUP_URL = settings.get('DUP_URL')
        self.DUP_CHANNEL = settings.get('DUP_CHANNEL')
        self.DOUBLE_DUP_DOMAIN = settings.get('DOUBLE_DUP_DOMAIN')

        self.detail_headers = {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
           "Accept-Encoding": "gzip, deflate, br",
           "Accept-Language": "zh-CN,zh;q=0.9",
           "Cache-Control": "max-age=0",
           "Connection": "keep-alive",
           "Cookie": "device_id=99e35e4a4e21f065553327c17e7a2107; s=dk12klit5a; __utma=1.1795507188.1632276874.1632276874.1632276874.1; __utmz=1.1632276874.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); acw_tc=2760829316367077210477752e21083b74d1073931bb0936872f031aa34d5a; xq_a_token=bbbce7f3f0e179adfe66962174d84eb7adafeeda; xqat=bbbce7f3f0e179adfe66962174d84eb7adafeeda; xq_r_token=91e53c5c325265960f1e0b108aaf481b810f2ebe; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOi0xLCJpc3MiOiJ1YyIsImV4cCI6MTYzODQ2ODQxMSwiY3RtIjoxNjM2NzA3NzA1MDI2LCJjaWQiOiJkOWQwbjRBWnVwIn0.cTEMqRwX0S3ePbDhpVlGlc3yjLLRHO1nyWdlPXoBh_mv8CBIt5PLeo0fi0a0s_9yNp9p_8aRvp0vd-FbjFFHz-pVQrsF0Xb2lNweioQAps6aW5J75myxKPnwff2ts3iR6sAMfDQd8Edlt-xOU8GF7pMDfBPZljUNY59z80FzJgZxaP2YvF4Uydy4A42cCEn5RXuihAXxY09SP4M08unYp3t7xow5B7GL7SR0VU_NcrpM2G7lWXDjeGvo9Rvu35IJvLRopIOl-4NwLbjTjN0upsVyOBfavEuJKChQggSt6xg3WMhyei2IFxjL2l9TBy1lT1pFt-PZWSv6IaJ6JKivCA; u=921636707721058; Hm_lvt_1db88642e346389874251b5a1eded6e3=1634881234,1635404753,1636444234,1636707722; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1636707728",
           "Host": "xueqiu.com",
           "sec-ch-ua": "\"Chromium\";v=\"94\", \"Google Chrome\";v=\"94\", \";Not A Brand\";v=\"99\"",
           "sec-ch-ua-mobile": "?0",
           "sec-ch-ua-platform": "\"Windows\"",
           "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Site": "none",
           "Sec-Fetch-User": "?1",
           "Upgrade-Insecure-Requests": "1",
           "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"}

        self.logger = get_logger('wemedia_comment', logger_path)

    def formatEntryUrl(self,cfg):
        cfg["total_page"]+=1
        tmp_url = cfg["detail_url"].format(cfg["detail_id"],cfg["total_page"])
        self.logger.info("datil_id=%s,datil_url=%s" % (cfg["detail_id"], tmp_url))

        # self.detail_headers = {"User-Agent": ua.chrome}
        get_data = dupClient.getPara(self.DUP_URL, self.DUP_CHANNEL, cfg["detail_id"])
        if get_data == "empty":
            self.logger.error("ID not in database,Please enter an ID that exists in the database.")
            comments_update = True
        else:
            get_comment_obj = json.loads(get_data)
            comments_update = get_comment_obj.get("comment_index",False)
        if not comments_update:
            Whether_Crawler= self.WhetherCrawler(cfg)
            if Whether_Crawler:
                request = scrapy.Request(tmp_url, callback=self.parse,headers=self.detail_headers)
                request.meta['cfg'] = copy.deepcopy(cfg)
                return request
            else:
                self.logger.info("No need to update comments!")
                return
        else:
            request = scrapy.Request(tmp_url, callback=self.parse,headers=self.detail_headers)
            request.meta['cfg'] = copy.deepcopy(cfg)
            return request


    def WhetherCrawler(self,cfg):

        url = cfg["detail_url"].format(cfg["detail_id"],cfg["total_page"])
        GolaxyDownloader = golaxy_Downloader(call_proxy=1)
        HTML = GolaxyDownloader.get(url,headers=self.detail_headers)
        json_data =json.loads(HTML)
        comments_count = int(json_data.get("count",0))
        get_data = dupClient.getPara(self.DUP_URL, self.DUP_CHANNEL, cfg["detail_id"])

        get_comment_obj = json.loads(get_data)
        # 如果评论采集过comment_index_v1=False，默认为True
        comment_index_v1 = get_comment_obj.get("comment_index",True)

        comments_data = {}
        comments_data["comments_count"] = comments_count
        comments_data["comment_index"] = comment_index_v1
        params = json.dumps(comments_data)
        dupClient.confirm(self.DUP_URL, self.DUP_CHANNEL, cfg["detail_id"],params)
        if not comment_index_v1:
            return comment_index_v1
        if comments_count == get_comment_obj["comments_count"]:
            return False
        else:
            return True

    def parse(self,response):

        cfg = response.meta["cfg"]
        cfg["total_page"]+=1
        json_obj = json.loads(response.body)

        datas = json_obj.get("comments")

        for data in datas:

            item = WemediaCommentItem()
            item.init()

            item["media_name"] = cfg["site_name"]
            item["media_id"] = cfg["site_id"]
            user_data = data.get("user")
            item["comment_id"] = data.get("id")
            item["user_id"] = user_data.get("id")
            item["user_name"] = user_data.get("screen_name")
            item["screen_name"] = user_data.get("screen_name")
            item["publish_time"] = data.get("created_at")
            item["content"] = data.get("text")
            item["comments_count"] = int(data.get("reply_count"))
            item["gather_time"] = int(time.time()*1000)
            item["url"] = cfg["url"]
            reply_comment_data = data.get("reply_comment","")
            if isinstance(reply_comment_data,dict):
                item["parent_id"] =reply_comment_data.get("id")
            # 和文章关联的id
            item["root_id"] = cfg["detail_id"]
            item["likes_count"] = data.get("like_count",0)

            isExist = dupClient.findAndSet(self.DUP_URL, self.DUP_CHANNEL, 3600, item["comment_id"])
            if isExist:
                continue

            comments_data = {}
            comments_data["comments_count"] = item['comments_count']
            # 采集过 comments_data=False
            comments_data["comment_index"] = False
            params = json.dumps(comments_data)
            dupClient.confirm(self.DUP_URL, self.DUP_CHANNEL, cfg["detail_id"], params)
            dupClient.confirm(self.DUP_URL, self.DUP_CHANNEL, item["comment_id"])
            yield item
            # print(json.dumps(item, ensure_ascii=False))

        if cfg["total_page"]<=10:
            cfg["total_page"] += 1

            tmp_url = cfg["detail_url"].format(cfg["detail_id"],cfg["total_page"])
            request = scrapy.Request(tmp_url, callback=self.parse, headers=self.detail_headers)
            request.meta['cfg'] = copy.deepcopy(cfg)
            yield request

